```javascript
const { Telegraf } = require('telegraf');
const { User } = require('../models/User');
const { Conversation } = require('../models/Conversation');
const { logger } = require('../utils/logger');

class TelegramService {
  async start(ctx) {
    try {
      const user = await User.findById(ctx.from.id);
      if (!user) {
        await User.create({ id: ctx.from.id, username: ctx.from.username });
      }
      ctx.reply('Selamat datang!');
    } catch (error) {
      logger.error('Error pada perintah start:', error);
    }
  }

  async help(ctx) {
    try {
      ctx.reply('Tolong!');
    } catch (error) {
      logger.error('Error pada perintah help:', error);
    }
  }
}

module.exports = new TelegramService();
```