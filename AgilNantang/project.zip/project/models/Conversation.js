```javascript
const mongoose = require('mongoose');

const conversationSchema = new mongoose.Schema({
  id: String,
  userId: String,
  messages: [{ type: String }],
});

module.exports = mongoose.model('Conversation', conversationSchema);
```