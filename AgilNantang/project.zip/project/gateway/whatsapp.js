/**
 * gateway/whatsapp.js — WhatsApp Bot Gateway for SI BABU
 */

'use strict';

const { Client, LocalAuth } = require('whatsapp-web.js');
const qrcode = require('qrcode-terminal');
const orchestrator = require('../orchestrator');

function init() {
  const enabled = process.env.WHATSAPP_ENABLED === 'true';
  if (!enabled) {
    console.log('[whatsapp] Gateway tidak diaktifkan (WHATSAPP_ENABLED=false)');
    return;
  }

  const client = new Client({
    authStrategy: new LocalAuth(),
    puppeteer: {
      headless: true,
      args: ['--no-sandbox', '--disable-setuid-sandbox'],
    }
  });

  console.log('[whatsapp] Memulai client...');

  client.on('qr', (qr) => {
    console.log('[whatsapp] Scan QR code ini untuk login:');
    qrcode.generate(qr, { small: true });
  });

  client.on('ready', () => {
    console.log('[whatsapp] Gateway ONLINE');
  });

  client.on('message', async (msg) => {
    // Abaikan pesan dari grup atau status
    if (msg.from.includes('@g.us') || msg.isStatus) return;

    const input = msg.body;
    if (!input) return;

    console.log(`[whatsapp] Pesan dari ${msg.from}: ${input}`);

    try {
      const result = await orchestrator.run(input, { history: [] });
      
      if (result.success) {
        await msg.reply(result.output);
      } else {
        await msg.reply(`Waduh, ada masalah: ${result.error || 'Gagal memproses.'}`);
      }
    } catch (err) {
      console.error('[whatsapp] Error:', err.message);
      await msg.reply('Gue lagi pusing, coba lagi nanti ya... 🤕');
    }
  });

  client.initialize().catch(err => {
    console.error('[whatsapp] Gagal inisialisasi:', err.message);
  });
}

module.exports = { init };
