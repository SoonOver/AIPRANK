/**
 * gateway/telegram.js — Telegram Bot Gateway for SI BABU
 */

'use strict';

const TelegramBot = require('node-telegram-bot-api');
const orchestrator = require('../orchestrator');
const logger = require('../utils/logger');

function init() {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) {
    console.log('[telegram] TELEGRAM_BOT_TOKEN tidak ditemukan, gateway dilewati.');
    return;
  }

  const bot = new TelegramBot(token, { polling: true });

  console.log('[telegram] Gateway ONLINE');

  // Handle Command /start
  bot.onText(/\/start/, (msg) => {
    const chatId = msg.chat.id;
    bot.sendMessage(chatId, 'Halo! Gue SI BABU, AI Agent lo. Ada yang bisa gue bantu? 😄\n\nKetik apa aja, nanti gue proses.');
  });

  // Handle Command /help
  bot.onText(/\/help/, (msg) => {
    const chatId = msg.chat.id;
    const helpText = `
Daftar Perintah:
/start - Mulai percakapan
/help  - Tampilkan bantuan
/status - Cek status sistem

Gue bisa bantu:
• Buat script/aplikasi (build)
• Perbaiki kode error (fix)
• Cari informasi (research)
• Ngobrol santai (chat)
    `;
    bot.sendMessage(chatId, helpText);
  });

  // Handle Common Messages
  bot.on('message', async (msg) => {
    if (!msg.text || msg.text.startsWith('/')) return;

    const chatId = msg.chat.id;
    const input  = msg.text;

    // Kirim feedback "typing..."
    bot.sendChatAction(chatId, 'typing');

    try {
      const result = await orchestrator.run(input, { history: [] });
      
      if (result.success) {
        // Jika output terlalu panjang, pecah atau kirim sebagai file jika perlu
        if (result.output.length > 4000) {
          const chunks = result.output.match(/[\s\S]{1,4000}/g);
          for (const chunk of chunks) {
            await bot.sendMessage(chatId, chunk);
          }
        } else {
          await bot.sendMessage(chatId, result.output);
        }
      } else {
        await bot.sendMessage(chatId, `Waduh, ada masalah: ${result.error || 'Gagal memproses permintaan.'}`);
      }
    } catch (err) {
      console.error('[telegram] Error:', err.message);
      bot.sendMessage(chatId, 'Gue lagi pusing, coba lagi nanti ya... 🤕');
    }
  });

  // Handle Error
  bot.on('polling_error', (err) => {
    if (err.code === 'ETELEGRAM' && err.message.includes('401')) {
      console.error('[telegram] Token salah atau tidak valid.');
      bot.stopPolling();
    }
  });
}

module.exports = { init };
